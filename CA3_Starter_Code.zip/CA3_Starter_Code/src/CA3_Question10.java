/**
 *  Name:
 *  Class Group:
 */
public class CA3_Question10
{

    public static void main(String[] args) {

    }
}
