/**
 *  Name:
 *  Class Group:
 */
public class CA3_Question1
{
    public static void runSimulation()
    {

    }

    public static void main(String[] args) {
        runSimulation();
    }
}
