/**
 *  Name:
 *  Class Group:
 */

public class CA3_Question5
{

    public static void main(String[] args)
    {

    }
}
